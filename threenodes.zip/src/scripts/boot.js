require(['text!../../examples/module.json', 'cs!threenodes/App'], function (modules, App) {
  //console.log(typeof(modules));
  return new App({modules: JSON.parse(modules)});
});
