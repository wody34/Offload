var express = require('express');
var app = express();
var path = require('path'),
    cors = require('cors');

var querystring = require('querystring');

var request = require('request');

app.use(cors());
app.use('/assets', express.static(__dirname + '/assets'));
app.use('/examples', express.static(__dirname + '/examples'));
app.use('/public', express.static(__dirname + '/public'));
app.use('/src', express.static(__dirname + '/src'));


var target_ip = 'test.ncl.kaist.ac.kr'

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname , '/index.html'));
});

app.listen(55555, function () {
    console.log('Example app listening on port 55555!');
});

app.get('/test', function(req, res){
    request('http://143.248.2.209:8080/C2V_Sim/verify', function (error, response, body) {
        if (!error && response.statusCode == 200) {
            //console.log(body);
            res.send(body);
            res.end();
        }
    });
});

app.get('/C2VSim_NetworkThroughput', function(req, res){
    request('http://'+target_ip+':8080/C2VSim/C2VSim_NetworkThroughput', function (error, response, body) {
        if (!error && response.statusCode == 200) {
            res.send(body);
            res.end();
        }
    });
});

app.get('/C2VSim_Model', function(req, res){
    request({
        headers: {
            //'Content-Length': contentLength,
            'Content-Type': 'application/json'
        },
        //uri: 'http://143.248.2.209:8080/C2V_Sim/C2VSim_Model',
        uri: 'http://'+target_ip+':8080/C2VModel',
        body: JSON.stringify(req.query),
        method: 'POST'
    }, function optionalCallback(err, httpResponse, body) {
        if(err){
            return console.error('upload failed:', err);
        }
        res.send(body);
        res.end();
    });
});

app.get('/C2VSim_App', function(req, res){
    request({
        headers: {
            //'Content-Length': contentLength,
            'Content-Type': 'application/json'
        },
        uri: 'http://'+target_ip+':8080/C2VApp/2',
        body: JSON.stringify(req.query),
        method: 'POST'
    }, function optionalCallback(err, httpResponse, body) {
        if(err){
            return console.error('upload failed:', err);
        }
        res.send(body);
        res.end();
    });
});

app.get('/C2VSim_State', function(req, res){
    request('http://'+target_ip+':8080/C2VSim/C2VSim_State', function (error, response, body) {
        if (!error && response.statusCode == 200) {
            //console.log(body);
            res.send(body);
            res.end();
        }
    });
});

app.get('/C2VSim_Start', function(req, res){
    request('http://'+target_ip+':8080/C2VSim/C2VSim_Start?model=5722fb049bd57fcd022cc5fa&app=5722fb189bd57fcd022cc5fc', function (error, response, body) {
        if (!error && response.statusCode == 200) {
            //console.log(body);
            res.send(body);
            res.end();
        }
    });
});